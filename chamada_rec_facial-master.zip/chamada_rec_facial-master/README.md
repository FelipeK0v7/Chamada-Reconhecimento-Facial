# chamada_rec_facial
um sistema para subistituir a chamda em uma sala de aula usando reconhecimento facial com face_recognition

para instalar (no ubuntu) basta executar o install.sh, em caso de erros de instalação
ou durante a execução favor abrir um inssue
--este foi meu primeiro shell script então ele tem muito a ser otimizado ainda--

=D

Basicamente, a ideia é que usando deste algoritimo qualquer um poderia cadastrar os alunos usando uma imagem e o nome de cada um este pudesse ter a lista de presença de maneira mais organica e rápida

para usar:

coloque os nomes em ordem alfabetica no alunos.txt e insira fotos que mostrem o rosto deles de maneira clara na pasta imagens também rotulada com os nomes deles
